package jadt.graphics;

public class Gradient {
}
