package jadt.core;

import java.awt.*;
import java.awt.image.ImageObserver;
import java.awt.image.ImageProducer;

public class SystemTray {
    private final java.awt.SystemTray systemTray = java.awt.SystemTray.getSystemTray();
    //private TrayIcon tray = new TrayIcon(createImage("images/bulb.gif", "tray icon"));

}

