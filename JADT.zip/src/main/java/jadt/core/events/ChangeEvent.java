package jadt.core.events;

import javax.swing.event.ChangeListener;

public abstract class ChangeEvent implements ChangeListener{
}
