package jadt.core.events;

import java.awt.event.ContainerListener;

public abstract class ContainerEvent implements ContainerListener {

}
