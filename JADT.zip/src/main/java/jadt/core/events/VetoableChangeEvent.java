package jadt.core.events;

import java.beans.VetoableChangeListener;

public abstract class VetoableChangeEvent implements VetoableChangeListener {
}
