package jadt.core.events;

import java.awt.event.MouseWheelListener;

public abstract class MouseWheelEvent implements MouseWheelListener {
}
