package jadt.core.events;

import java.awt.event.ItemListener;

public abstract class ItemEvent implements ItemListener {
}
