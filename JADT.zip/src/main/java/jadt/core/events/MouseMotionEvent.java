package jadt.core.events;

import java.awt.event.MouseEvent;

public abstract class MouseMotionEvent implements java.awt.event.MouseMotionListener {
    @Override
    public void mouseDragged(MouseEvent e) {

    }

    @Override
    public void mouseMoved(MouseEvent e) {

    }
}
