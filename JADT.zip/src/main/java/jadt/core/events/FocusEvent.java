package jadt.core.events;

import java.awt.event.FocusListener;

public abstract class FocusEvent implements FocusListener {
}
