package jadt.core.events;

import javax.swing.event.AncestorListener;

public abstract class AncestorEvent implements AncestorListener {
}
