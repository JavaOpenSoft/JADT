package jadt.layouts;

public class FlowLayout {
    public java.awt.FlowLayout flowLayout = new java.awt.FlowLayout();
    public java.awt.FlowLayout getLayout() {
        return new java.awt.FlowLayout();
    }
}
