package jadt.layouts;

public class SpringLayout {
    public javax.swing.SpringLayout getLayout() {
        return new javax.swing.SpringLayout();
    }
}
