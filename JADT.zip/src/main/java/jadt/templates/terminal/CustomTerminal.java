package jadt.templates.terminal;

public class CustomTerminal {
}
