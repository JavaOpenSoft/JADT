package jadt.templates.loginscreen;

public class LoginScreen {
}
