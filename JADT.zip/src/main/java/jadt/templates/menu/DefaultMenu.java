package jadt.templates.menu;

public class DefaultMenu {
}
