package jadt.templates.menu;

public class DefaultMacOSScreenMenuBar {
}
