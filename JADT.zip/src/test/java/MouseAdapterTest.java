import jadt.core.Window;
import jadt.utils.OSUtils;

public class MouseAdapterTest {
    static Window window = new Window();

    public static void main(String[] args) {
        System.out.println(OSUtils.getOs());
    }
}
