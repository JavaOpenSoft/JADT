package jadt.templates.texteditor;

public class TextEditor {
}
