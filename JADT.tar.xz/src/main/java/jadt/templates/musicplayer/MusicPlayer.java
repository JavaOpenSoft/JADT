package jadt.templates.musicplayer;

public class MusicPlayer {
}
