package jadt.utils.thread;

public abstract class ThreadTask extends Thread {
    @Override
    public abstract void run();
}
