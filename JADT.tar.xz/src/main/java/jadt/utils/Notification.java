package jadt.utils;

public class Notification {
}
