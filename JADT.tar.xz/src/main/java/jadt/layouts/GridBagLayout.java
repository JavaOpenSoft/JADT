package jadt.layouts;

public class GridBagLayout {
    public java.awt.GridBagLayout getLayout() {
        return new java.awt.GridBagLayout();
    }
}
