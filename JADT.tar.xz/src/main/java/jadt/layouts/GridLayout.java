package jadt.layouts;

public class GridLayout {
    public java.awt.GridLayout getLayout() {
        return new java.awt.GridLayout();
    }
}
