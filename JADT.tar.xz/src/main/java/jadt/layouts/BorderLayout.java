package jadt.layouts;

public class BorderLayout {
    public java.awt.BorderLayout getLayout() {return new java.awt.BorderLayout();}
}
