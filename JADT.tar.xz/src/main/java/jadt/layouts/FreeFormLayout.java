package jadt.layouts;

public class FreeFormLayout {
    @SuppressWarnings("SameReturnValue")
    public Object getLayout()
    {
        return null;
    }
}
