package jadt.core;

public class PrintDialog {

}
