package jadt.core.events;

import java.awt.event.InputMethodListener;

public abstract class InputMethodEvent implements InputMethodListener {
}
