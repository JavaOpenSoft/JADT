package jadt.core.events;

public abstract class ActionEvent implements java.awt.event.ActionListener {
    @Override
    public void actionPerformed(java.awt.event.ActionEvent e) {

    }
}
