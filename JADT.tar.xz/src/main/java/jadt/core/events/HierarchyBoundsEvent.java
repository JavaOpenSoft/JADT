package jadt.core.events;

import java.awt.event.HierarchyBoundsListener;

public abstract class HierarchyBoundsEvent implements HierarchyBoundsListener {

}
