package jadt.core.events;

import java.awt.event.HierarchyListener;

public abstract class HierarchyEvent implements HierarchyListener {
}
