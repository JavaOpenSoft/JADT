package jadt.core.events;

import java.awt.event.WindowListener;

public abstract class WindowEvent implements WindowListener {
}
