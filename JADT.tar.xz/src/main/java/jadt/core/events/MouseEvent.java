package jadt.core.events;

import java.awt.event.MouseListener;

public abstract class MouseEvent implements MouseListener {
}
