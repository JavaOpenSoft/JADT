package jadt.core.events;


import java.awt.event.ComponentListener;

public abstract class ComponentEvent implements ComponentListener {

}
