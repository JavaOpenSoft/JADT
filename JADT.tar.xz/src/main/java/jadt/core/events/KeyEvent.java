package jadt.core.events;

import java.awt.event.KeyListener;

public abstract class KeyEvent implements KeyListener {
}
