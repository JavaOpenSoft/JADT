package jadt.resources;

import java.awt.Image;
import java.awt.Toolkit;

public class DefaultImages {
    public Image ErrorImage = Toolkit.getDefaultToolkit().getImage("jadt/resources/error.png");
    public Image SuccessImage = Toolkit.getDefaultToolkit().getImage("jadt/resources/success.png");
    public Image WarningImage = Toolkit.getDefaultToolkit().getImage("jadt/resources/error.png");
    public Image AboutImage = Toolkit.getDefaultToolkit().getImage("jadt/resources/About.png");
}

