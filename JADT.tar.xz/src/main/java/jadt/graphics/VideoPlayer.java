package jadt.graphics;

public class VideoPlayer {
    public void addVideo(){

    }
}
