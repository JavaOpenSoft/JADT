package jadt.graphics;

public class GradientText {
}
