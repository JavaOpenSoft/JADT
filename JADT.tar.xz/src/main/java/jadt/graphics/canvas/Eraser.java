package jadt.graphics.canvas;

public class Eraser {

}
