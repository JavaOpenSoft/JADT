
import jadt.core.Window;

public class WindowTest {

    public static void main(String[] args) {
        Window window = new Window();
    }
}
